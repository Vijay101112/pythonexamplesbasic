import csv
import copy
myVechile = {
    "vin" : "      ",
    "make": "       ",
    "model": "      ",
    "year": 0,
    "range": 0,
    "topSpeed": 0,
    "ZeroSixty": 0.0,
    "mileage": 0
}
myInventoryList = []
# Assuming myVehicle is defined somewhere above
for key, value in myVechile.items():
    print(" {}  : {} ".format(key, value))
           
    # Open the CSV file outside of the loop for reading
with open('carFleet.csv') as csvFile:
        csvReader = csv.reader(csvFile, delimiter=',')  
        lineCount = 0

        # Loop through each row in the CSV file
        for row in csvReader:
            if lineCount == 0:
                print(f'Column names are: {", ".join(row)}')  
                lineCount += 1  
            else:  
                print(f'vin: {row[0]} make: {row[1]}, model: {row[2]}, year: {row[3]}, range: {row[4]}, topSpeed: {row[5]}, zeroSixty: {row[6]}, mileage: {row[7]}')  
                
                # Create a deep copy of myVehicle and update it with CSV data
                currentVehicle = copy.deepcopy(myVechile )  
                currentVehicle["vin"] = row[0]  
                currentVehicle["make"] = row[1]  
                currentVehicle["model"] = row[2]  
                currentVehicle["year"] = row[3]  
                currentVehicle["range"] = row[4]  
                currentVehicle["topSpeed"] = row[5]  
                currentVehicle["zeroSixty"] = row[6]  
                currentVehicle["mileage"] = row[7]  

                # Add the updated vehicle to the inventory list
                myInventoryList.append(currentVehicle)  
                lineCount += 1
print("\nFinal Inventory List:")
for vehicle in myInventoryList:
    print(vehicle)