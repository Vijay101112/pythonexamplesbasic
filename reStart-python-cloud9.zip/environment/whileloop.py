import random
number = random.randint(1,10)
print("Welcome to Guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")
isGuessRight = False
while isGuessRight != True:
    guessnumber = input("Guess a number between 1 and 10: ")
    if int(guessnumber)== number:
        print("you guessed {}. is correct. You win!".format(guessnumber))
        isGuessRight = True
    else:
        print("you guessed {}. is wrong . Try again".format(guessnumber))
