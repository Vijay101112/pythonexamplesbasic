userreply = input("Do you want to ship package? (Enter yes or no) ")
if userreply == "yes":
    print("we can help you to ship package")
else:
    print("please come back when you neee to ship package. Thankyou")
userreply = input("would you like to buy stamp , envelop or make a copy?(Enter stamps,envelope or copy) ")
if userreply == "stamp":
    print("We have many stamp designs to choose from")
elif userreply == "envelope":
    print("We have many envelope sizes to choose from.")    
elif userreply == "copy":
    copies = input("how many copies do you need? (Enter a no)")
    print("here are {} copies".format(copies))
else:
    print("thankyou")